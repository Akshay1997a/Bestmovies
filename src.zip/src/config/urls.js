export const APP_PLAYSTORE_URL = 'https://bestmovie.com';
