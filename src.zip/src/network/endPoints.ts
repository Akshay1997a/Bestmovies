export const endPoints = {
    BASE_URL:"http://3.144.9.39:3002/",
    translate:"translations/",
    languageList:"countries?",
    languageData:"languages",
}