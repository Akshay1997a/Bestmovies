export default {
    getForm: () =>{

    },
}