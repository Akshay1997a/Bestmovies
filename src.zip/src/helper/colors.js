export default {
    "white":"#FFFFFF",
    "black": "#000000",
    "tomatoRed": "#FF3300",
    "tomatoRedLight": "#FFAD9A",
    "lightGrey": "#EFEFEF",
    "borderColor": "#A2A2A2",
    "marinerBlue": "#336bda",
    light_orange:"#ffdbcc",
    blue_color:"#4183e2",
    "black33":"#333333",
    "black": "#000000"
}